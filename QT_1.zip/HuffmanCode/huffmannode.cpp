#include "huffmannode.h"

huffmanNode::huffmanNode()
{

}
