#ifndef HUFFMANTREE_H
#define HUFFMANTREE_H
#include <iostream>
#include <string>
#include <vector>
using namespace std;
class HuffmanTree
{
private:

public:
    HuffmanTree();
    ~HuffmanTree();







};


#endif // HUFFMANTREE_H
