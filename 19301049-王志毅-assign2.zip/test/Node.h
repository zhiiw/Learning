#ifndef NODE_H
#define NODE_H
template <class T>
struct Node{
    Node *next;
    int val;
};
#endif // NODE_H
