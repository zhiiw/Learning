/********************************************************************************
** Form generated from reading UI file 'TextFinder.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEXTFINDER_H
#define UI_TEXTFINDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MonkeyUI
{
public:
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *keyWord;
    QLineEdit *lineEdit;
    QLabel *label;
    QLineEdit *lineEdit_2;
    QPushButton *findButton;
    QTextEdit *textEdit;
    QLabel *label_2;

    void setupUi(QWidget *MonkeyUI)
    {
        if (MonkeyUI->objectName().isEmpty())
            MonkeyUI->setObjectName(QString::fromUtf8("MonkeyUI"));
        MonkeyUI->resize(800, 600);
        verticalLayout = new QVBoxLayout(MonkeyUI);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        keyWord = new QLabel(MonkeyUI);
        keyWord->setObjectName(QString::fromUtf8("keyWord"));

        horizontalLayout->addWidget(keyWord);

        lineEdit = new QLineEdit(MonkeyUI);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        horizontalLayout->addWidget(lineEdit);

        label = new QLabel(MonkeyUI);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit_2 = new QLineEdit(MonkeyUI);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        horizontalLayout->addWidget(lineEdit_2);

        findButton = new QPushButton(MonkeyUI);
        findButton->setObjectName(QString::fromUtf8("findButton"));

        horizontalLayout->addWidget(findButton);


        verticalLayout->addLayout(horizontalLayout);

        textEdit = new QTextEdit(MonkeyUI);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        verticalLayout->addWidget(textEdit);

        label_2 = new QLabel(MonkeyUI);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout->addWidget(label_2, 0, Qt::AlignBottom);


        retranslateUi(MonkeyUI);

        QMetaObject::connectSlotsByName(MonkeyUI);
    } // setupUi

    void retranslateUi(QWidget *MonkeyUI)
    {
        MonkeyUI->setWindowTitle(QCoreApplication::translate("MonkeyUI", "TextFinder", nullptr));
        keyWord->setText(QCoreApplication::translate("MonkeyUI", "\347\214\264\345\255\220\346\200\273\346\225\260", nullptr));
        label->setText(QCoreApplication::translate("MonkeyUI", "\347\274\226\345\217\267", nullptr));
        findButton->setText(QCoreApplication::translate("MonkeyUI", "\345\274\200\345\247\213\346\270\270\346\210\217", nullptr));
        label_2->setText(QCoreApplication::translate("MonkeyUI", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MonkeyUI: public Ui_MonkeyUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TEXTFINDER_H
