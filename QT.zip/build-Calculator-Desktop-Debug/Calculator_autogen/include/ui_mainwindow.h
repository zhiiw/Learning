/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTextEdit *textEdit;
    QTextEdit *textEdit_2;
    QLabel *label;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_8;
    QPushButton *plusButton;
    QPushButton *subButton;
    QPushButton *leftButton;
    QPushButton *rightButton;
    QPushButton *powerTButton;
    QPushButton *oneButton;
    QPushButton *twoButton;
    QPushButton *threeButton;
    QPushButton *mulButton;
    QPushButton *paiButton;
    QPushButton *fourButton_2;
    QPushButton *fourButton;
    QPushButton *sixButton;
    QPushButton *divButton;
    QPushButton *eButton;
    QPushButton *sevenButton;
    QPushButton *eightButton;
    QPushButton *nineButton;
    QPushButton *equalButton;
    QPushButton *powerButton;
    QPushButton *lnButton;
    QPushButton *rootButton;
    QPushButton *acButton;
    QPushButton *dotButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(985, 516);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(70, 20, 521, 91));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setWeight(75);
        textEdit->setFont(font);
        textEdit->setReadOnly(false);
        textEdit_2 = new QTextEdit(centralwidget);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(610, 90, 321, 361));
        textEdit_2->setReadOnly(true);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(660, 30, 201, 41));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);
        label->setMargin(51);
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(70, 128, 520, 321));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_8 = new QPushButton(layoutWidget);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setFont(font1);

        gridLayout->addWidget(pushButton_8, 0, 0, 1, 1);

        plusButton = new QPushButton(layoutWidget);
        plusButton->setObjectName(QString::fromUtf8("plusButton"));
        QFont font2;
        font2.setPointSize(20);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setWeight(75);
        font2.setStrikeOut(false);
        plusButton->setFont(font2);

        gridLayout->addWidget(plusButton, 0, 1, 1, 1);

        subButton = new QPushButton(layoutWidget);
        subButton->setObjectName(QString::fromUtf8("subButton"));
        subButton->setFont(font1);

        gridLayout->addWidget(subButton, 0, 2, 1, 1);

        leftButton = new QPushButton(layoutWidget);
        leftButton->setObjectName(QString::fromUtf8("leftButton"));
        leftButton->setFont(font1);

        gridLayout->addWidget(leftButton, 0, 3, 1, 1);

        rightButton = new QPushButton(layoutWidget);
        rightButton->setObjectName(QString::fromUtf8("rightButton"));
        rightButton->setFont(font1);

        gridLayout->addWidget(rightButton, 0, 4, 1, 1);

        powerTButton = new QPushButton(layoutWidget);
        powerTButton->setObjectName(QString::fromUtf8("powerTButton"));
        powerTButton->setFont(font1);

        gridLayout->addWidget(powerTButton, 1, 0, 1, 1);

        oneButton = new QPushButton(layoutWidget);
        oneButton->setObjectName(QString::fromUtf8("oneButton"));
        oneButton->setFont(font1);

        gridLayout->addWidget(oneButton, 1, 1, 1, 1);

        twoButton = new QPushButton(layoutWidget);
        twoButton->setObjectName(QString::fromUtf8("twoButton"));
        twoButton->setFont(font1);

        gridLayout->addWidget(twoButton, 1, 2, 1, 1);

        threeButton = new QPushButton(layoutWidget);
        threeButton->setObjectName(QString::fromUtf8("threeButton"));
        threeButton->setFont(font1);

        gridLayout->addWidget(threeButton, 1, 3, 1, 1);

        mulButton = new QPushButton(layoutWidget);
        mulButton->setObjectName(QString::fromUtf8("mulButton"));
        QFont font3;
        font3.setPointSize(20);
        mulButton->setFont(font3);

        gridLayout->addWidget(mulButton, 1, 4, 1, 1);

        paiButton = new QPushButton(layoutWidget);
        paiButton->setObjectName(QString::fromUtf8("paiButton"));
        paiButton->setFont(font1);

        gridLayout->addWidget(paiButton, 2, 0, 1, 1);

        fourButton_2 = new QPushButton(layoutWidget);
        fourButton_2->setObjectName(QString::fromUtf8("fourButton_2"));
        fourButton_2->setFont(font1);

        gridLayout->addWidget(fourButton_2, 2, 1, 1, 1);

        fourButton = new QPushButton(layoutWidget);
        fourButton->setObjectName(QString::fromUtf8("fourButton"));
        fourButton->setFont(font1);

        gridLayout->addWidget(fourButton, 2, 2, 1, 1);

        sixButton = new QPushButton(layoutWidget);
        sixButton->setObjectName(QString::fromUtf8("sixButton"));
        sixButton->setFont(font1);

        gridLayout->addWidget(sixButton, 2, 3, 1, 1);

        divButton = new QPushButton(layoutWidget);
        divButton->setObjectName(QString::fromUtf8("divButton"));
        divButton->setFont(font1);

        gridLayout->addWidget(divButton, 2, 4, 1, 1);

        eButton = new QPushButton(layoutWidget);
        eButton->setObjectName(QString::fromUtf8("eButton"));
        QFont font4;
        font4.setPointSize(14);
        font4.setBold(true);
        font4.setWeight(75);
        eButton->setFont(font4);

        gridLayout->addWidget(eButton, 3, 0, 1, 1);

        sevenButton = new QPushButton(layoutWidget);
        sevenButton->setObjectName(QString::fromUtf8("sevenButton"));
        sevenButton->setFont(font1);

        gridLayout->addWidget(sevenButton, 3, 1, 1, 1);

        eightButton = new QPushButton(layoutWidget);
        eightButton->setObjectName(QString::fromUtf8("eightButton"));
        eightButton->setFont(font1);

        gridLayout->addWidget(eightButton, 3, 2, 1, 1);

        nineButton = new QPushButton(layoutWidget);
        nineButton->setObjectName(QString::fromUtf8("nineButton"));
        nineButton->setFont(font1);

        gridLayout->addWidget(nineButton, 3, 3, 1, 1);

        equalButton = new QPushButton(layoutWidget);
        equalButton->setObjectName(QString::fromUtf8("equalButton"));
        equalButton->setFont(font1);

        gridLayout->addWidget(equalButton, 3, 4, 1, 1);

        powerButton = new QPushButton(layoutWidget);
        powerButton->setObjectName(QString::fromUtf8("powerButton"));
        powerButton->setFont(font1);

        gridLayout->addWidget(powerButton, 4, 0, 1, 1);

        lnButton = new QPushButton(layoutWidget);
        lnButton->setObjectName(QString::fromUtf8("lnButton"));
        lnButton->setFont(font1);

        gridLayout->addWidget(lnButton, 4, 1, 1, 1);

        rootButton = new QPushButton(layoutWidget);
        rootButton->setObjectName(QString::fromUtf8("rootButton"));
        rootButton->setFont(font3);

        gridLayout->addWidget(rootButton, 4, 2, 1, 1);

        acButton = new QPushButton(layoutWidget);
        acButton->setObjectName(QString::fromUtf8("acButton"));
        acButton->setFont(font1);

        gridLayout->addWidget(acButton, 4, 3, 1, 1);

        dotButton = new QPushButton(layoutWidget);
        dotButton->setObjectName(QString::fromUtf8("dotButton"));
        dotButton->setFont(font1);

        gridLayout->addWidget(dotButton, 4, 4, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 985, 23));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "History", nullptr));
        pushButton_8->setText(QCoreApplication::translate("MainWindow", "M+", nullptr));
        plusButton->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        subButton->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        leftButton->setText(QCoreApplication::translate("MainWindow", "\357\274\210", nullptr));
        rightButton->setText(QCoreApplication::translate("MainWindow", "\357\274\211", nullptr));
        powerTButton->setText(QCoreApplication::translate("MainWindow", "x^3", nullptr));
        oneButton->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        twoButton->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        threeButton->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        mulButton->setText(QCoreApplication::translate("MainWindow", "x", nullptr));
        paiButton->setText(QCoreApplication::translate("MainWindow", "\317\200", nullptr));
        fourButton_2->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        fourButton->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        sixButton->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        divButton->setText(QCoreApplication::translate("MainWindow", "\303\267", nullptr));
        eButton->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        sevenButton->setText(QCoreApplication::translate("MainWindow", "7", nullptr));
        eightButton->setText(QCoreApplication::translate("MainWindow", "8", nullptr));
        nineButton->setText(QCoreApplication::translate("MainWindow", "9", nullptr));
        equalButton->setText(QCoreApplication::translate("MainWindow", "=", nullptr));
        powerButton->setText(QCoreApplication::translate("MainWindow", "x^2", nullptr));
        lnButton->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        rootButton->setText(QCoreApplication::translate("MainWindow", "\342\210\232\357\277\243", nullptr));
        acButton->setText(QCoreApplication::translate("MainWindow", "C", nullptr));
        dotButton->setText(QCoreApplication::translate("MainWindow", "M-", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
